    <div class="prochain-creneau__element">
        {{titre_creneau}}
    </div>
    <div class="prochain-creneau__element">
        {{ouverture_creneau}}
    </div>
    <div class="prochain-creneau__element">
        {{fermeture_creneau}}
    </div>
