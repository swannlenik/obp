<div class="creneau">
    <div dir="ltr" class="prochain-creneau">
        {{main_content}}
    </div>
</div>
