<?php
$creneaux = getNextCreneaux();
?>

<div class="creer-creneau__div">
    <h1>Liste des créneaux des 7 prochains jours</h1>
    <table class="creer-creneau__table">
        <thead>
            <tr class="creer_creneau__table--line">
                <th class="creer_creneau__table--header-cell">Date du créneau</th>
                <th class="creer_creneau__table--header-cell">Horaires</th>
                <th class="creer_creneau__table--header-cell">Ouvert par</th>
                <th class="creer_creneau__table--header-cell">Heure d'ouverture</th>
                <th class="creer_creneau__table--header-cell">Fermé par</th>
                <th class="creer_creneau__table--header-cell">Heure de fermeture</th>
            </tr>
        </thead>
        <tbody>
            {{contentPage}}
        </tbody>
    </table>
</div>