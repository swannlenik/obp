<form method="POST" action="{{action}}" class="creneau_form">
    <input type="hidden" name="action" value="maj_ouverture_creneau">
    <input type="hidden" name="id_creneau" value="{{id}}" />
    <input type="submit" value="J'ouvre ce créneau">
</form>